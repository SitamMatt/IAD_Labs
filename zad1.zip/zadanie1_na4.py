import numpy as np
import plotly.graph_objects as go
import statistics
from neural_network import NeuralNetwork

approximation_train_1 = np.empty((0,1), float)
approximation_very_1 = np.empty((0,1), float)
with open('approximation_train_1.txt', "r") as inFile:
    for x in range(81):
        data = inFile.readline()
        data = data.split()
        approximation_very_1 = np.append(approximation_very_1, np.array([[data.pop()]], dtype=float), axis=0)
        approximation_train_1 = np.append(approximation_train_1, np.array([[data.pop()]], dtype=float), axis=0)


approximation_train_2 = np.empty((0,1), float)
approximation_very_2 = np.empty((0,1), float)
with open('approximation_train_2.txt', "r") as inFile:
    for x in range(15):
        data = inFile.readline()
        data = data.split()
        approximation_very_2 = np.append(approximation_very_2, np.array([[data.pop()]], dtype=float), axis=0)
        approximation_train_2 = np.append(approximation_train_2, np.array([[data.pop()]], dtype=float), axis=0)


approximation_test_data = np.empty((0,1), float)
approximation_test_very = np.empty((0,1), float)
with open('approximation_test.txt', "r") as inFile:
    for x in range(1000):
        data = inFile.readline()
        data = data.split()
        approximation_test_very = np.append(approximation_test_very, np.array([[data.pop()]], dtype=float), axis=0)
        approximation_test_data = np.append(approximation_test_data, np.array([[data.pop()]], dtype=float), axis=0)



# first for 4
aprox_1 = go.Figure()
aprox_2 = go.Figure()
x = np.arange(-4, 4, 0.01)
x = np.reshape(x, (-1, 1))
for i in range(5):
    NN_4 = NeuralNetwork(approximation_train_1, approximation_very_1, 4*i+1, 0.0002, 0, True, 'linear')
    NN_4_2 = NeuralNetwork(approximation_train_2, approximation_very_2, 4*i+1, 0.0002, 0, True, 'linear')
    for j in range(50000):
        if j % 10000 == 0:
            print(NN_4.verify(approximation_test_data,approximation_test_very))
        NN_4.train()
        NN_4_2.train()
    aprox_1.add_trace(go.Scatter(x=x.flatten(), y=NN_4.feedforward(x).flatten(),
                                 name=str(4*i+1) + ' Neurons'))
    aprox_2.add_trace(go.Scatter(x=x.flatten(), y=NN_4_2.feedforward(x).flatten(),
                                 name=str(4*i+1) + ' Neurons'))
aprox_1.add_trace(go.Scatter(x=approximation_test_data.flatten(), y=approximation_test_very.flatten(),
                             mode='markers',
                             marker=dict(size=1),
                             name='Test Data'))
aprox_2.add_trace(go.Scatter(x=approximation_test_data.flatten(), y=approximation_test_very.flatten(),
                             mode='markers',
                             marker=dict(size=1),
                             name='Test Data'))
aprox_1.add_trace(go.Scatter(x=approximation_train_1.flatten(), y=approximation_very_1.flatten(),
                             mode='markers',
                             marker=dict(size=3),
                             name='Data 1'))
aprox_2.add_trace(go.Scatter(x=approximation_train_2.flatten(), y=approximation_very_2.flatten(),
                             mode='markers',
                             marker=dict(size=3),
                             name='Data 2'))
aprox_1.update_layout(
    title="Approximation for data1",
    xaxis_title="X",
    yaxis_title="Y",
    )
aprox_2.update_layout(
    title="Approximation for data2",
    xaxis_title="X",
    yaxis_title="Y",
    )
aprox_1.show()
aprox_2.show()



# second for 4
aprox_3 = go.Figure()
aprox_4 = go.Figure()
x = np.arange(0,100000)
neuro = [1,5,19]
for i in range(3):
    NN_4s_error = []
    NN_4s_2_error = []
    NN_4s_test_error = []
    NN_4s_2_test_error = []
    neurons = neuro.pop()
    NN_4s = NeuralNetwork(approximation_train_1, approximation_very_1, neurons, 0.0002, 0, True, 'linear')
    NN_4s_2 = NeuralNetwork(approximation_train_2, approximation_very_2, neurons, 0.0002, 0, True, 'linear')
    for j in range(100000):
        NN_4s.train()
        NN_4s_2.train()

        NN_4s_error.append(NN_4s.error())
        NN_4s_test_error.append(NN_4s.verify(approximation_test_data,approximation_test_very))

        NN_4s_2_error.append(NN_4s_2.error())
        NN_4s_2_test_error.append(NN_4s_2.verify(approximation_test_data, approximation_test_very))

    aprox_3.add_trace(go.Scatter(x=x, y=NN_4s_error,
                                 name=str(neurons) + ' Neurons, Data1'))
    aprox_3.add_trace(go.Scatter(x=x, y=NN_4s_test_error,
                                 name=str(neurons) + ' Neurons, Test Data'))
    aprox_4.add_trace(go.Scatter(x=x, y=NN_4s_2_error,
                                 name=str(neurons) + ' Neurons, Data2'))
    aprox_4.add_trace(go.Scatter(x=x, y=NN_4s_2_test_error,
                                 name=str(neurons) + ' Neurons, Test Data'))
aprox_3.update_yaxes(type="log", range=[np.log10(0.05), np.log10(3)])
aprox_4.update_yaxes(type="log", range=[np.log10(0.05), np.log10(3)])
aprox_3.update_layout(
    title="Error in iterations (iter=100000,step=0,0002,momentum=0,bias=True)",
    xaxis_title="Iterations",
    yaxis_title="Error"
    )
aprox_4.update_layout(
    title="Error in iterations (iter=100000,step=0,0002,momentum=0,bias=True)",
    xaxis_title="Iterations",
    yaxis_title="Error"
    )
aprox_3.show()
aprox_4.show()

# third for 4
outFile = open('avarage_error_for_data1.txt', 'a+')
outFile2 = open('avarage_error_for_data2.txt', 'a+')
for i in range(1, 21):
    NN_4t_curr_error_data = []
    NN_4t_curr_error_test_data = []
    NN_4t_2_curr_error_data = []
    NN_4t_2_curr_error_test_data = []
    NN_4t = NeuralNetwork(approximation_train_1, approximation_very_1, i, 0.0002, 0, True, 'linear')
    NN_4t_2 = NeuralNetwork(approximation_train_2, approximation_very_2, i, 0.0002, 0, True, 'linear')
    for j in range(100):
        for g in range(30000):
            NN_4t.train()
            NN_4t_2.train()

        NN_4t_curr_error_data.append((NN_4t.error()))
        NN_4t_curr_error_test_data.append(NN_4t.verify(approximation_test_data,approximation_test_very))

        NN_4t_2_curr_error_data.append((NN_4t_2.error()))
        NN_4t_2_curr_error_test_data.append(NN_4t_2.verify(approximation_test_data,approximation_test_very))

        NN_4t.reset()
        NN_4t_2.reset()

    outFile.write(str(i) + ' ' + str(np.mean(NN_4t_curr_error_data)) + ' ' + str(statistics.pstdev(NN_4t_curr_error_data)) + ' ' + str(np.mean(NN_4t_curr_error_test_data)) + ' ' + str(
        statistics.pstdev(NN_4t_curr_error_test_data)) + '\n')
    outFile2.write(str(i) + ' ' + str(np.mean(NN_4t_2_curr_error_data)) + ' ' + str(statistics.pstdev(NN_4t_2_curr_error_data)) + ' ' + str(np.mean(NN_4t_2_curr_error_test_data)) + ' ' + str(
        statistics.pstdev(NN_4t_2_curr_error_test_data)) + '\n')

outFile.close()
outFile2.close()

# fourth for 4
aprox_5 = go.Figure()
aprox_6 = go.Figure()
x = np.arange(-4,4,0.01)
x = np.reshape(x, (-1,1))
NN_4f = NeuralNetwork(approximation_train_1, approximation_very_1, 7, 0.0002, 0, True, 'linear')
NN_4f_2 = NeuralNetwork(approximation_train_2, approximation_very_2, 7, 0.0002, 0, True, 'linear')
for j in range(100001):
    NN_4f.train()
    NN_4f_2.train()
    if j % 20000 == 0:
        aprox_5.add_trace(go.Scatter(x=x.flatten(), y=NN_4f.feed(x).flatten(),
                                     name=str(j) + ' Iterations'))
        aprox_6.add_trace(go.Scatter(x=x.flatten(), y=NN_4f_2.feed(x).flatten(),
                                     name=str(j) + ' Iterations'))
aprox_5.update_layout(
    title="Change of funtions through iterations for Data1",
    xaxis_title="X",
    yaxis_title="Y",
    )
aprox_6.update_layout(
    title="Change of funtions through iterations for Data2",
    xaxis_title="X",
    yaxis_title="Y",
    )
aprox_5.show()
aprox_6.show()
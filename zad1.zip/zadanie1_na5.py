
import numpy as np
import plotly.graph_objects as go
import statistics
from neural_network import NeuralNetwork

# loading data for 5
classification_train = np.empty((0,4), float)
classification_very = np.empty((0,3), int)
# Reading training data from file
with open('classification_train.txt', "r") as inFile:
    for x in range(90):
        data = inFile.readline()
        data = data.split()
        y = int(data.pop())
        if y == 1:
            classification_very = np.append(classification_very, np.array([[1, 0, 0]]), axis=0)
        if y == 2:
            classification_very = np.append(classification_very, np.array([[0, 1, 0]]), axis=0)
        if y == 3:
            classification_very = np.append(classification_very, np.array([[0, 0, 1]]), axis=0)
        classification_train = np.append(classification_train, np.array([data], dtype=float), axis=0)
# print(classification_train)
# print(classification_very)

classification_train_1000 = np.reshape(classification_train[:, 0], (-1, 1))
classification_train_0100 = np.reshape(classification_train[:, 1], (-1, 1))
classification_train_0010 = np.reshape(classification_train[:, 2], (-1, 1))
classification_train_0001 = np.reshape(classification_train[:, 3], (-1, 1))
classification_train_1100 = np.append(classification_train_1000, classification_train_0100, axis=1)
classification_train_0011 = np.append(classification_train_0010, classification_train_0001, axis=1)
classification_train_1001 = np.append(classification_train_1000, classification_train_0001, axis=1)
classification_train_0110 = np.append(classification_train_0100, classification_train_0010, axis=1)
classification_train_1010 = np.append(classification_train_1000, classification_train_0010, axis=1)
classification_train_0101 = np.append(classification_train_0100, classification_train_0001, axis=1)
classification_train_1110 = np.append(classification_train_1100, classification_train_0010, axis=1)
classification_train_0111 = np.append(classification_train_0110, classification_train_0001, axis=1)
classification_train_1011 = np.append(classification_train_1000, classification_train_0011, axis=1)
classification_train_1101 = np.append(classification_train_1100, classification_train_0001, axis=1)

classification_test_data = np.empty((0, 4), float)
classification_test_very = np.empty((0, 1), int)
with open('classification_test.txt', "r") as inFile:
    for x in range(93):
        data = inFile.readline()
        data = data.split()
        classification_test_very = np.append(classification_test_very, np.array([[int(data.pop())]]), axis=0)
        classification_test_data = np.append(classification_test_data, np.array([data], dtype=float), axis=0)
# print(classification_test_data)
# print(classification_test_very)

classification_test_very_2 = classification_test_very[0:90]

classification_test_1000 = np.reshape(classification_test_data[:, 0], (-1, 1))
classification_test_0100 = np.reshape(classification_test_data[:, 1], (-1, 1))
classification_test_0010 = np.reshape(classification_test_data[:, 2], (-1, 1))
classification_test_0001 = np.reshape(classification_test_data[:, 3], (-1, 1))
classification_test_1100 = np.append(classification_test_1000, classification_test_0100, axis=1)
classification_test_0011 = np.append(classification_test_0010, classification_test_0001, axis=1)
classification_test_1001 = np.append(classification_test_1000, classification_test_0001, axis=1)
classification_test_0110 = np.append(classification_test_0100, classification_test_0010, axis=1)
classification_test_1010 = np.append(classification_test_1000, classification_test_0010, axis=1)
classification_test_0101 = np.append(classification_test_0100, classification_test_0001, axis=1)
classification_test_1110 = np.append(classification_test_1100, classification_test_0010, axis=1)
classification_test_0111 = np.append(classification_test_0110, classification_test_0001, axis=1)
classification_test_1011 = np.append(classification_test_1000, classification_test_0011, axis=1)
classification_test_1101 = np.append(classification_test_1100, classification_test_0001, axis=1)

# first for 5
class_1000 = go.Figure()
class_0100 = go.Figure()
class_0010 = go.Figure()
class_0001 = go.Figure()
class_1100 = go.Figure()
class_0011 = go.Figure()
class_1001 = go.Figure()
class_0110 = go.Figure()
class_1010 = go.Figure()
class_0101 = go.Figure()
class_1110 = go.Figure()
class_0111 = go.Figure()
class_1011 = go.Figure()
class_1101 = go.Figure()
class_1111 = go.Figure()

x = np.arange(0, 5000)
for i in range(5):
    print(i)
    neuro = 4*i+1
    step = 0.002
    mom = 0
    NN_5_1000_error = []
    NN_5_0100_error = []
    NN_5_0010_error = []
    NN_5_0001_error = []
    NN_5_1100_error = []
    NN_5_0011_error = []
    NN_5_1001_error = []
    NN_5_0110_error = []
    NN_5_1010_error = []
    NN_5_0101_error = []
    NN_5_1110_error = []
    NN_5_0111_error = []
    NN_5_1011_error = []
    NN_5_1101_error = []
    NN_5_1111_error = []

    NN_5_1000_test_error = []
    NN_5_0100_test_error = []
    NN_5_0010_test_error = []
    NN_5_0001_test_error = []
    NN_5_1100_test_error = []
    NN_5_0011_test_error = []
    NN_5_1001_test_error = []
    NN_5_0110_test_error = []
    NN_5_1010_test_error = []
    NN_5_0101_test_error = []
    NN_5_1110_test_error = []
    NN_5_0111_test_error = []
    NN_5_1011_test_error = []
    NN_5_1101_test_error = []
    NN_5_1111_test_error = []

    NN_5_1000 = NeuralNetwork(classification_train_1000, classification_very, neuro, step, mom, True)
    NN_5_0100 = NeuralNetwork(classification_train_0100, classification_very, neuro, step, mom, True)
    NN_5_0010 = NeuralNetwork(classification_train_0010, classification_very, neuro, step, mom, True)
    NN_5_0001 = NeuralNetwork(classification_train_0001, classification_very, neuro, step, mom, True)
    NN_5_1100 = NeuralNetwork(classification_train_1100, classification_very, neuro, step, mom, True)
    NN_5_0011 = NeuralNetwork(classification_train_0011, classification_very, neuro, step, mom, True)
    NN_5_1001 = NeuralNetwork(classification_train_1001, classification_very, neuro, step, mom, True)
    NN_5_0110 = NeuralNetwork(classification_train_0110, classification_very, neuro, step, mom, True)
    NN_5_1010 = NeuralNetwork(classification_train_1010, classification_very, neuro, step, mom, True)
    NN_5_0101 = NeuralNetwork(classification_train_0101, classification_very, neuro, step, mom, True)
    NN_5_1110 = NeuralNetwork(classification_train_1110, classification_very, neuro, step, mom, True)
    NN_5_0111 = NeuralNetwork(classification_train_0111, classification_very, neuro, step, mom, True)
    NN_5_1011 = NeuralNetwork(classification_train_1011, classification_very, neuro, step, mom, True)
    NN_5_1101 = NeuralNetwork(classification_train_1101, classification_very, neuro, step, mom, True)
    NN_5_1111 = NeuralNetwork(classification_train, classification_very, neuro, step, mom, True)

    for j in range(5000):
        NN_5_1000.train()
        NN_5_0100.train()
        NN_5_0010.train()
        NN_5_0001.train()
        NN_5_1100.train()
        NN_5_0011.train()
        NN_5_1001.train()
        NN_5_0110.train()
        NN_5_1010.train()
        NN_5_0101.train()
        NN_5_1110.train()
        NN_5_0111.train()
        NN_5_1011.train()
        NN_5_1101.train()
        NN_5_1111.train()

        NN_5_1000_error.append(NN_5_1000.verify_percentage(classification_train_1000, classification_test_very_2))
        NN_5_0100_error.append(NN_5_0100.verify_percentage(classification_train_0100, classification_test_very_2))
        NN_5_0010_error.append(NN_5_0010.verify_percentage(classification_train_0010, classification_test_very_2))
        NN_5_0001_error.append(NN_5_0001.verify_percentage(classification_train_0001, classification_test_very_2))
        NN_5_1100_error.append(NN_5_1100.verify_percentage(classification_train_1100, classification_test_very_2))
        NN_5_0011_error.append(NN_5_0011.verify_percentage(classification_train_0011, classification_test_very_2))
        NN_5_1001_error.append(NN_5_1001.verify_percentage(classification_train_1001, classification_test_very_2))
        NN_5_0110_error.append(NN_5_0110.verify_percentage(classification_train_0110, classification_test_very_2))
        NN_5_1010_error.append(NN_5_1010.verify_percentage(classification_train_1010, classification_test_very_2))
        NN_5_0101_error.append(NN_5_0101.verify_percentage(classification_train_0101, classification_test_very_2))
        NN_5_1110_error.append(NN_5_1110.verify_percentage(classification_train_1110, classification_test_very_2))
        NN_5_0111_error.append(NN_5_0111.verify_percentage(classification_train_0111, classification_test_very_2))
        NN_5_1011_error.append(NN_5_1011.verify_percentage(classification_train_1011, classification_test_very_2))
        NN_5_1101_error.append(NN_5_1101.verify_percentage(classification_train_1101, classification_test_very_2))
        NN_5_1111_error.append(NN_5_1111.verify_percentage(classification_train, classification_test_very_2))

        NN_5_1000_test_error.append(NN_5_1000.verify_percentage(classification_test_1000, classification_test_very))
        NN_5_0100_test_error.append(NN_5_0100.verify_percentage(classification_test_0100, classification_test_very))
        NN_5_0010_test_error.append(NN_5_0010.verify_percentage(classification_test_0010, classification_test_very))
        NN_5_0001_test_error.append(NN_5_0001.verify_percentage(classification_test_0001, classification_test_very))
        NN_5_1100_test_error.append(NN_5_1100.verify_percentage(classification_test_1100, classification_test_very))
        NN_5_0011_test_error.append(NN_5_0011.verify_percentage(classification_test_0011, classification_test_very))
        NN_5_1001_test_error.append(NN_5_1001.verify_percentage(classification_test_1001, classification_test_very))
        NN_5_0110_test_error.append(NN_5_0110.verify_percentage(classification_test_0110, classification_test_very))
        NN_5_1010_test_error.append(NN_5_1010.verify_percentage(classification_test_1010, classification_test_very))
        NN_5_0101_test_error.append(NN_5_0101.verify_percentage(classification_test_0101, classification_test_very))
        NN_5_1110_test_error.append(NN_5_1110.verify_percentage(classification_test_1110, classification_test_very))
        NN_5_0111_test_error.append(NN_5_0111.verify_percentage(classification_test_0111, classification_test_very))
        NN_5_1011_test_error.append(NN_5_1011.verify_percentage(classification_test_1011, classification_test_very))
        NN_5_1101_test_error.append(NN_5_1101.verify_percentage(classification_test_1101, classification_test_very))
        NN_5_1111_test_error.append(NN_5_1111.verify_percentage(classification_test_data, classification_test_very))

    class_1000.add_trace(go.Scatter(x=x, y=NN_5_1000_error, name=str(neuro) + ' Neurons, self verify'))
    class_1000.add_trace(go.Scatter(x=x, y=NN_5_1000_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_0100.add_trace(go.Scatter(x=x, y=NN_5_0100_error, name=str(neuro) + ' Neurons, self verify'))
    class_0100.add_trace(go.Scatter(x=x, y=NN_5_0100_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_0010.add_trace(go.Scatter(x=x, y=NN_5_0010_error, name=str(neuro) + ' Neurons, self verify'))
    class_0010.add_trace(go.Scatter(x=x, y=NN_5_0010_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_0001.add_trace(go.Scatter(x=x, y=NN_5_0001_error, name=str(neuro) + ' Neurons, self verify'))
    class_0001.add_trace(go.Scatter(x=x, y=NN_5_0001_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_1100.add_trace(go.Scatter(x=x, y=NN_5_1100_error, name=str(neuro) + ' Neurons, self verify'))
    class_1100.add_trace(go.Scatter(x=x, y=NN_5_1100_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_0011.add_trace(go.Scatter(x=x, y=NN_5_0011_error, name=str(neuro) + ' Neurons, self verify'))
    class_0011.add_trace(go.Scatter(x=x, y=NN_5_0011_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_1001.add_trace(go.Scatter(x=x, y=NN_5_1001_error, name=str(neuro) + ' Neurons, self verify'))
    class_1001.add_trace(go.Scatter(x=x, y=NN_5_1001_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_0110.add_trace(go.Scatter(x=x, y=NN_5_0110_error, name=str(neuro) + ' Neurons, self verify'))
    class_0110.add_trace(go.Scatter(x=x, y=NN_5_0110_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_1010.add_trace(go.Scatter(x=x, y=NN_5_1010_error, name=str(neuro) + ' Neurons, self verify'))
    class_1010.add_trace(go.Scatter(x=x, y=NN_5_1010_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_0101.add_trace(go.Scatter(x=x, y=NN_5_0101_error, name=str(neuro) + ' Neurons, self verify'))
    class_0101.add_trace(go.Scatter(x=x, y=NN_5_0101_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_1110.add_trace(go.Scatter(x=x, y=NN_5_1110_error, name=str(neuro) + ' Neurons, self verify'))
    class_1110.add_trace(go.Scatter(x=x, y=NN_5_1110_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_0111.add_trace(go.Scatter(x=x, y=NN_5_0111_error, name=str(neuro) + ' Neurons, self verify'))
    class_0111.add_trace(go.Scatter(x=x, y=NN_5_0111_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_1011.add_trace(go.Scatter(x=x, y=NN_5_1011_error, name=str(neuro) + ' Neurons, self verify'))
    class_1011.add_trace(go.Scatter(x=x, y=NN_5_1011_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_1101.add_trace(go.Scatter(x=x, y=NN_5_1101_error, name=str(neuro) + ' Neurons, self verify'))
    class_1101.add_trace(go.Scatter(x=x, y=NN_5_1101_test_error, name=str(neuro) + ' Neurons, test verify'))

    class_1111.add_trace(go.Scatter(x=x, y=NN_5_1111_error, name=str(neuro) + ' Neurons, self verify'))
    class_1111.add_trace(go.Scatter(x=x, y=NN_5_1111_test_error, name=str(neuro) + ' Neurons, test verify'))

class_1000.update_yaxes(range=[0, 100])
class_0100.update_yaxes(range=[0, 100])
class_0010.update_yaxes(range=[0, 100])
class_0001.update_yaxes(range=[0, 100])
class_1100.update_yaxes(range=[0, 100])
class_0011.update_yaxes(range=[0, 100])
class_1001.update_yaxes(range=[0, 100])
class_0110.update_yaxes(range=[0, 100])
class_1010.update_yaxes(range=[0, 100])
class_0101.update_yaxes(range=[0, 100])
class_1110.update_yaxes(range=[0, 100])
class_0111.update_yaxes(range=[0, 100])
class_1011.update_yaxes(range=[0, 100])
class_1101.update_yaxes(range=[0, 100])
class_1111.update_yaxes(range=[0, 100])

class_1000.update_layout(title="Percentage in iterations (1 input[ 1 | 0 | 0 | 0 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_0100.update_layout(title="Percentage in iterations (1 input[ 0 | 1 | 0 | 0 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_0010.update_layout(title="Percentage in iterations (1 input[ 0 | 0 | 1 | 0 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_0001.update_layout(title="Percentage in iterations (1 input[ 0 | 0 | 0 | 1 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_1100.update_layout(title="Percentage in iterations (2 input[ 1 | 1 | 0 | 0 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_0011.update_layout(title="Percentage in iterations (2 input[ 0 | 0 | 1 | 1 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_1001.update_layout(title="Percentage in iterations (2 input[ 1 | 0 | 0 | 1 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_0110.update_layout(title="Percentage in iterations (2 input[ 0 | 1 | 1 | 0 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_1010.update_layout(title="Percentage in iterations (2 input[ 1 | 0 | 1 | 0 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_0101.update_layout(title="Percentage in iterations (2 input[ 0 | 1 | 0 | 1 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_1110.update_layout(title="Percentage in iterations (3 input[ 1 | 1 | 1 | 0 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_0111.update_layout(title="Percentage in iterations (3 input[ 0 | 1 | 1 | 1 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_1011.update_layout(title="Percentage in iterations (3 input[ 1 | 0 | 1 | 1 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_1101.update_layout(title="Percentage in iterations (3 input[ 1 | 1 | 0 | 1 ])", xaxis_title="Iterations", yaxis_title="Percentage")
class_1111.update_layout(title="Percentage in iterations (4 input[ 1 | 1 | 1 | 1 ])", xaxis_title="Iterations", yaxis_title="Percentage")

class_1000.show()
class_0100.show()
class_0010.show()
class_0001.show()
class_1100.show()
class_0011.show()
class_1001.show()
class_0110.show()
class_1010.show()
class_0101.show()
class_1110.show()
class_0111.show()
class_1011.show()
class_1101.show()
class_1111.show()

# second for 5
outFile = open('avarage_percentage.txt', 'a+')
for i in range(1, 21):
    print(i)
    NN_5s_curr_percentage_data = []
    NN_5s_curr_percentage_test_data = []
    NN_5s = NeuralNetwork(classification_train, classification_very, i, 0.002, 0, True)
    for j in range(100):
        for g in range(10000):
            NN_5s.train()

        NN_5s_curr_percentage_data.append(NN_5s.verify_percentage(classification_train, classification_test_very_2))
        NN_5s_curr_percentage_test_data.append(NN_5s.verify_percentage(classification_test_data,classification_test_very))

        NN_5s.reset()

    outFile.write(str(i) + ' ' + str(np.mean(NN_5s_curr_percentage_data)) + ' ' + str(statistics.pstdev(NN_5s_curr_percentage_data)) + ' ' + str(np.mean(NN_5s_curr_percentage_test_data)) + ' ' + str(
        statistics.pstdev(NN_5s_curr_percentage_test_data)) + '\n')

outFile.close()

#third for 5
def getGridData(train, grid_size):
    x_min = train[:, 0].min() - 0.5
    x_max = train[:, 0].max() + 0.5
    y_min = train[:, 1].min() - 0.5
    y_max = train[:, 1].max() + 0.5

    x_step = (x_max - x_min) / (grid_size-1)
    y_step = (y_max - y_min) / (grid_size-1)
    x = np.arange(x_min, x_max+0.00000000001, x_step)
    y = np.arange(y_min, y_max+0.00000000001, y_step)
    x_tmp = np.empty((0, 1), float)
    for sample in x:
        x_tmp = np.append(x_tmp, np.full((grid_size, 1), sample), axis=0)
    y_tmp = np.empty((0, 1), float)
    y = np.reshape(y, (-1, 1))
    for sample in y:
        y_tmp = np.append(y_tmp, y, axis=0)
    xy = np.append(x_tmp, y_tmp, axis=1)
    y = y.flatten()

    return x, y, xy


grid_size = 300
neuro_t = 6
step_t = 0.002
mom_t = 0

x_1100, y_1100, xy_1100 = getGridData(classification_train_1100, grid_size)
x_0011, y_0011, xy_0011 = getGridData(classification_train_0011, grid_size)
x_1001, y_1001, xy_1001 = getGridData(classification_train_1001, grid_size)
x_0110, y_0110, xy_0110 = getGridData(classification_train_0110, grid_size)
x_1010, y_1010, xy_1010 = getGridData(classification_train_1010, grid_size)
x_0101, y_0101, xy_0101 = getGridData(classification_train_0101, grid_size)

NN_5t_1100 = NeuralNetwork(classification_train_1100, classification_very, neuro_t, step_t, mom_t, True)
NN_5t_0011 = NeuralNetwork(classification_train_0011, classification_very, neuro_t, step_t, mom_t, True)
NN_5t_1001 = NeuralNetwork(classification_train_1001, classification_very, neuro_t, step_t, mom_t, True)
NN_5t_0110 = NeuralNetwork(classification_train_0110, classification_very, neuro_t, step_t, mom_t, True)
NN_5t_1010 = NeuralNetwork(classification_train_1010, classification_very, neuro_t, step_t, mom_t, True)
NN_5t_0101 = NeuralNetwork(classification_train_0101, classification_very, neuro_t, step_t, mom_t, True)

for i in range(50000):
    NN_5t_1100.train()
    NN_5t_0011.train()
    NN_5t_1001.train()
    NN_5t_0110.train()
    NN_5t_1010.train()
    NN_5t_0101.train()

#calculate heatmaps
NN_5t_1100_heatmap = NN_5t_1100.feed2(xy_1100)
NN_5t_0011_heatmap = NN_5t_0011.feed2(xy_0011)
NN_5t_1001_heatmap = NN_5t_1001.feed2(xy_1001)
NN_5t_0110_heatmap = NN_5t_0110.feed2(xy_0110)
NN_5t_1010_heatmap = NN_5t_1010.feed2(xy_1010)
NN_5t_0101_heatmap = NN_5t_0101.feed2(xy_0101)

NN_5t_1100_heatmap = np.reshape(NN_5t_1100_heatmap.flatten(),(grid_size,grid_size), order='F')
NN_5t_0011_heatmap = np.reshape(NN_5t_0011_heatmap.flatten(),(grid_size,grid_size), order='F')
NN_5t_1001_heatmap = np.reshape(NN_5t_1001_heatmap.flatten(),(grid_size,grid_size), order='F')
NN_5t_0110_heatmap = np.reshape(NN_5t_0110_heatmap.flatten(),(grid_size,grid_size), order='F')
NN_5t_1010_heatmap = np.reshape(NN_5t_1010_heatmap.flatten(),(grid_size,grid_size), order='F')
NN_5t_0101_heatmap = np.reshape(NN_5t_0101_heatmap.flatten(),(grid_size,grid_size), order='F')

colorscale = [[0, "rgb(0, 0, 255)"], [0.5, "rgb(0, 255, 0)"], [1, "rgb(255, 0, 0)"]]
colorscale2 = [[0, "rgb(0, 0, 200)"], [0.5, "rgb(0, 200, 0)"], [1, "rgb(200, 0, 0)"]]

class_1100t = go.Figure(data=go.Contour(z=NN_5t_1100_heatmap, x=x_1100, y=y_1100, colorscale=colorscale2, showscale=False, opacity=0.5))
class_0011t = go.Figure(data=go.Contour(z=NN_5t_0011_heatmap, x=x_0011, y=y_0011, colorscale=colorscale2, showscale=False, opacity=0.5))
class_1001t = go.Figure(data=go.Contour(z=NN_5t_1001_heatmap, x=x_1001, y=y_1001, colorscale=colorscale2, showscale=False, opacity=0.5))
class_0110t = go.Figure(data=go.Contour(z=NN_5t_0110_heatmap, x=x_0110, y=y_0110, colorscale=colorscale2, showscale=False, opacity=0.5))
class_1010t = go.Figure(data=go.Contour(z=NN_5t_1010_heatmap, x=x_1010, y=y_1010, colorscale=colorscale2, showscale=False, opacity=0.5))
class_0101t = go.Figure(data=go.Contour(z=NN_5t_0101_heatmap, x=x_0101, y=y_0101, colorscale=colorscale2, showscale=False, opacity=0.5))

class_1100t.add_trace(go.Scatter(x=classification_train_1000.flatten(), y=classification_train_0100.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very_2.flatten(), line=dict(color='White', width=1)), name='train data'))
class_1100t.add_trace(go.Scatter(x=classification_test_1000.flatten(), y=classification_test_0100.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very.flatten(), line=dict(color='Black', width=1)), name='test data'))
class_0011t.add_trace(go.Scatter(x=classification_train_0010.flatten(), y=classification_train_0001.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very_2.flatten(), line=dict(color='White', width=1)), name='train data'))
class_0011t.add_trace(go.Scatter(x=classification_test_0010.flatten(), y=classification_test_0001.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very.flatten(), line=dict(color='Black', width=1)), name='test data'))
class_1001t.add_trace(go.Scatter(x=classification_train_1000.flatten(), y=classification_train_0001.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very_2.flatten(), line=dict(color='White', width=1)), name='train data'))
class_1001t.add_trace(go.Scatter(x=classification_test_1000.flatten(), y=classification_test_0001.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very.flatten(), line=dict(color='Black', width=1)), name='test data'))
class_0110t.add_trace(go.Scatter(x=classification_train_0100.flatten(), y=classification_train_0010.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very_2.flatten(), line=dict(color='White', width=1)), name='train data'))
class_0110t.add_trace(go.Scatter(x=classification_test_0100.flatten(), y=classification_test_0010.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very.flatten(), line=dict(color='Black', width=1)), name='test data'))
class_1010t.add_trace(go.Scatter(x=classification_train_1000.flatten(), y=classification_train_0010.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very_2.flatten(), line=dict(color='White', width=1)), name='train data'))
class_1010t.add_trace(go.Scatter(x=classification_test_1000.flatten(), y=classification_test_0010.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very.flatten(), line=dict(color='Black', width=1)), name='test data'))
class_0101t.add_trace(go.Scatter(x=classification_train_0100.flatten(), y=classification_train_0001.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very_2.flatten(), line=dict(color='White', width=1)), name='train data'))
class_0101t.add_trace(go.Scatter(x=classification_test_0100.flatten(), y=classification_test_0001.flatten(), mode='markers', marker=dict(size=6, colorscale=colorscale, color=classification_test_very.flatten(), line=dict(color='Black', width=1)), name='test data'))

class_1100t.update_layout(title="Classification visualization (2 input[ 1 | 1 | 0 | 0 ])", xaxis_title="X", yaxis_title="Y")
class_0011t.update_layout(title="Classification visualization (2 input[ 0 | 0 | 1 | 1 ])", xaxis_title="X", yaxis_title="Y")
class_1001t.update_layout(title="Classification visualization (2 input[ 1 | 0 | 0 | 1 ])", xaxis_title="X", yaxis_title="Y")
class_0110t.update_layout(title="Classification visualization (2 input[ 0 | 1 | 1 | 0 ])", xaxis_title="X", yaxis_title="Y")
class_1010t.update_layout(title="Classification visualization (2 input[ 1 | 0 | 1 | 0 ])", xaxis_title="X", yaxis_title="Y")
class_0101t.update_layout(title="Classification visualization (2 input[ 0 | 1 | 0 | 1 ])", xaxis_title="X", yaxis_title="Y")

class_1100t.show()
class_0011t.show()
class_1001t.show()
class_0110t.show()
class_1010t.show()
class_0101t.show()

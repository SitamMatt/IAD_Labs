
import numpy as np


# Class definition
class NeuralNetwork:
    def __init__(self, train_data_input, train_data_output, hidden_neurons, step, momentum, bias, output_layer_activation = 'sigmoid', hidden_layer_activation = 'sigmoid'):
        self.bias = bias
        self.input = train_data_input
        self.output_layer_activation = output_layer_activation
        self.hidden_layer_activation = hidden_layer_activation
        if self.bias:   # adding column of 1s as bias input
            self.input = np.append(self.input, np.ones((self.input.shape[0], 1)), axis=1)
        self.y = train_data_output
        self.hidden_neurons = hidden_neurons
        self.weights1 = (np.random.rand(self.input.shape[1], hidden_neurons) * 2) - 1   # creating weight1 matrix
        self.weights2 = (np.random.rand(hidden_neurons+bias, self.y.shape[1]) * 2) - 1  # creating weight2 matrix
        self.output = np.zeros(self.y.shape)
        self.step = step
        self.momentum = momentum
        self.d_w1_tmp = 0
        self.d_w2_tmp = 0
        self.layer1_tmp = 0

    def activation(self, a, function):
        if  function == 'sigmoid':
            return 1 / (1 + np.exp(-a))
        if function == 'linear':
            return a

    def activation_derivative(self, d, function):
        if  function == 'sigmoid':
            return d * (1 - d)
        if function == 'linear':
            return 1

    def feedforward(self, w=np.empty((0,0))):
        if len(w):   # checking for different input to feedforward
            if self.bias:
                w = np.append(w, np.ones((w.shape[0], 1)), axis=1)   # adding column of 1s as bias input
            self.input = w
        self.layer1 = self.activation(np.dot(self.input, self.weights1), self.hidden_layer_activation)    # calculating value of hidden layer
        self.layer1_tmp = self.layer1
        if self.bias:
            self.layer1 = np.append(self.layer1, np.ones((self.layer1.shape[0], 1)), axis=1)    # adding column of 1s as bias input
        self.layer2 = self.activation(np.dot(self.layer1, self.weights2), self.output_layer_activation)  # calculating value of output layer
        return self.layer2

    def backprop(self):
        self.o_error = self.y - self.output  # error in output
        self.o_delta = self.o_error * self.activation_derivative(self.layer2,self.output_layer_activation)  # applying derivative of activation function to o_error

        self.layer1_error = self.o_delta.dot(self.weights2.T)
        self.layer1_delta = self.layer1_error * self.activation_derivative(self.layer1,self.hidden_layer_activation)  # applying derivative of activation function to layer1 error

        if (self.bias):
            self.layer1_delta = self.layer1_delta[:, 0:self.hidden_neurons]

        delta_w1 = self.step * self.input.T.dot(self.layer1_delta) + (self.momentum * self.d_w1_tmp)  # calculating weights1 changes
        delta_w2 = self.step * self.layer1.T.dot(self.o_delta) + (self.momentum * self.d_w2_tmp)  # calculating weights2 changes

        self.weights1 += delta_w1
        self.weights2 += delta_w2

        self.d_w1_tmp = delta_w1
        self.d_w2_tmp = delta_w2

    def train(self):
        self.output = self.feedforward()
        self.backprop()

    def error(self):
        return np.mean(np.square(self.y - self.feedforward()))

    def reset(self):
        self.weights1 = (np.random.rand(self.input.shape[1], self.hidden_neurons) * 2) - 1
        self.weights2 = (np.random.rand(self.hidden_neurons+self.bias, self.y.shape[1]) * 2) - 1

    def verify(self, test_data , test_very):
        layer2 = self.feed(test_data)
        return np.mean(np.square(test_very - layer2))

    def feed(self, test_data):
        if self.bias:
            test_data = np.append(test_data, np.ones((test_data.shape[0], 1)), axis=1)   # adding column of 1s as bias input
        layer1 = self.activation(np.dot(test_data, self.weights1), self.hidden_layer_activation)    # calculating value of hidden layer
        if self.bias:
            layer1 = np.append(layer1, np.ones((layer1.shape[0], 1)), axis=1)    # adding column of 1s as bias input
        layer2 = self.activation(np.dot(layer1, self.weights2), self.output_layer_activation)  # calculating value of output layer
        return layer2

    def verify_percentage(self, w, v):
        guess_temp = self.feed2(w)
        return (np.sum(guess_temp == v)/v.shape[0]) * 100

    def feed2(self, w):
        output = self.feed(w)
        guess_temp = np.empty((0, 1), int)
        for sample in output:
            guess_temp = np.append(guess_temp, np.array([[np.argmax(sample)+1]]), axis=0)
        return guess_temp
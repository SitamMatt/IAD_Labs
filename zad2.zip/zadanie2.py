import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as img 
import math
import random
import copy


def pointsInCircle(a, b, n):
    print("Podaj promien:")
    circle_r = float(input())
    pi = math.pi
    array = []
    for x in range(n):
        alpha = 2 * pi * random.random()
        r = circle_r * math.sqrt(random.random())
        array.append([math.cos(alpha)*r + a, math.sin(alpha)*r + b])
    return np.array(array)


def pointsOnCircle(a, b, n):
    print("Podaj promien:")
    r = float(input())
    pi = math.pi
    array = []
    for x in range(n):
        rand = np.random.uniform(0, 2)
        array.append([math.cos(2*pi/n*x+pi*rand)*r + a, math.sin(2*pi/n*x+pi*rand)*r + b])
    return np.array(array)


def pointsInRectangle(a, b, n):
    print("Podaj dlugosc:")
    lenght = float(input())/2
    print("Podaj wysokosc:")
    width = float(input())/2
    return np.array([[np.random.uniform(a-lenght, a+lenght), np.random.uniform(b-width, b+width)] for _ in range(n)])


def pointsInSquare(a, b, n):
    print("Podaj dlugosc:")
    lenght = float(input())/2
    return np.array([[np.random.uniform(a-lenght, a+lenght), np.random.uniform(b-lenght, b+lenght)] for _ in range(n)])


def pointsOnLine(a, b, n):
    points = np.array(getPointFromUser(2))
    x = points[:, 0]
    y = points[:, 1]
    coef = np.polyfit(x, y, 1)
    poly = np.poly1d(coef)
    x_axis = [np.random.uniform(x[0], x[1]) for _ in range(n)]
    y_axis = poly(x_axis)
    return np.array(list(zip(x_axis, y_axis)))


def pointsInTriangle(a, b, n):
    points = getPointFromUser(3)
    return np.array([pointInTriangle(points[0], points[1], points[2]) for _ in range(n)])


def pointInTriangle(p1, p2, p3):
    s, t = sorted([random.random(), random.random()])
    return (s * p1[0] + (t-s)*p2[0] + (1-t)*p3[0],
            s * p1[1] + (t-s)*p2[1] + (1-t)*p3[1])


def getPointFromUser(n):
    points = []
    print("Podaj wspolrzedne punktow:")
    for i in range(n):
        print("X"+str(i)+":")
        x = float(input())
        print("Y"+str(i)+":")
        y = float(input())
        points.append([x, y])
    return points


def pointsInQuadrangle(a, b, n):
    points = np.array(getPointFromUser(4))
    points_sorted = np.zeros((4,2))
    center_pos = [np.mean(points[:, 0]), np.mean(points[:, 1])]
    for i in range(4):
        vector_to_center = points[i] - center_pos
        if vector_to_center[0] > 0:
            if vector_to_center[1] > 0:
                points_sorted[2] = points[i]
            else:
                points_sorted[1] = points[i]
        else:
            if vector_to_center[1] > 0:
                points_sorted[3] = points[i]
            else:
                points_sorted[0] = points[i]
    triang1 = np.array([pointInTriangle(points_sorted[0], points_sorted[1], points_sorted[2]) for _ in range(int(n/2))])
    return np.append(triang1, np.array([pointInTriangle(points_sorted[0], points_sorted[2], points_sorted[3]) for _ in range(int((n+1)/2))]),axis=0)


def getPointsInFigures(x):
    return {
        1: pointsInCircle,
        2: pointsOnCircle,
        3: pointsInRectangle,
        4: pointsInSquare,
        5: pointsOnLine,
        6: pointsInTriangle,
        7: pointsInQuadrangle
    }[x]


def getWinnerFuntion(x):
    return {
        'gas': findWinnerIndexArray,
        'kohonen': findWinnerIndex
    }[x]


def distance(x_sample, c_sample):
    return np.sqrt((x_sample[0] - c_sample[0]) ** 2 + (x_sample[1] - c_sample[1]) ** 2)


def findWinnerIndexArray(sample_X, C, tired_array): #do leniwych zrob tak ze maja dodatkowa kolumne z iloscia tur do poczekania
    distances = np.array([[distance(sample_X, C[j]), int(j)] for j in range(len(C))])
    distances = distances[np.argsort(distances[:, 0])]
    winer_index_array = distances[:, 1]
    for _ in range(len(tired_array)):
        if winer_index_array[0] in tired_array:
            winer_index_array = np.delete(winer_index_array, 0)
    return winer_index_array


def findWinnerIndex(sample_X, C, tired_array):
    distances = [distance(sample_X, C[j]) for j in range(len(C))]
    while np.argmin(distances) in tired_array:
        distances[np.argmin(distances)] = 999  # = distances[np.argmax(distances)]+1 optional
    return np.argmin(distances)


def updateNeuronsPositions(win_index_data, iteration, sample_X, C, learn_rate, neighbour_rate, all_iterations, algorithm, policy):
    if algorithm == 'gas':
        for i in range(len(win_index_data)):
            C[int(win_index_data[i])] = C[int(win_index_data[i])] + learnRate(learn_rate, iteration, all_iterations) * winnerPolicyGas(i, neighbour_rate, iteration, all_iterations) * (sample_X - C[int(win_index_data[i])])
    elif algorithm == 'kohonen':
        for i in range(len(C)):
            C[i] = C[i] + learnRate(learn_rate, iteration, all_iterations) * winnerPolicyKohonen(i, neighbour_rate, win_index_data, iteration, all_iterations, policy) * (sample_X - C[i])


def updateCentersPositions(X, C):
    for i in range(len(C)):
        if np.sum(X[:, 2] == i+1) != 0:
            C[i, 0] = np.mean(X[X[:, 2] == i+1][:, 0])
            C[i, 1] = np.mean(X[X[:, 2] == i+1][:, 1])


def learnRate(learn_rate, iteration, all_iterations):
    pcs_left = 1 - ((iteration * 1.0) / all_iterations)
    return learn_rate * pcs_left


def eta(neighbour_rate, iteration, all_iterations):
    n = neighbour_rate * np.exp(-(iteration / all_iterations))
    return n


def winnerPolicyGas(curr_index, neighbour_rate, iteration, all_iterations):
    n = eta(neighbour_rate, iteration, all_iterations)
    return np.exp(-curr_index/((n**2)*2))


def winnerPolicyKohonen(curr_index, neighbour_rate, win_index, iteration, all_iterations, policy):
    if policy == 'WTA':
        if curr_index == win_index:
            return 1
        else:
            return 0
    elif policy == 'WTM':
        n = eta(neighbour_rate, iteration, all_iterations)
        return np.exp(-(abs(curr_index-win_index))/((n**2)*2))


def cost(X, C):
    cost = 0
    for i in range(len(X)):
        distances = [distance(X[i], C[j]) for j in range(len(C))]
        cost += distances[np.argmin(distances)]
    return cost / len(X)


def assignment(X, C):
    X_assigned = np.zeros((X.shape[0], X.shape[1]+1))
    X_assigned[:, :-1] = X
    for i in range(len(X)):
        distances = [distance(X[i], C[j]) for j in range(len(C))]
        X_assigned[i, 2] = np.argmin(distances)+1
    return X_assigned


def inactiveNeurons(X, C):
    inactive_neurons = 0
    for i in range(len(C)):
        if i+1 not in X[:, 2]:
            inactive_neurons += 1
    return inactive_neurons


def draw(X, C, type, center_data=None, algorithm='gas'):
    fig, ax = plt.subplots(figsize=(10, 10))
    for i in range(len(X)):
        if type == 'preview':
            ax.scatter(X[i, 0], X[i, 1], color='black', alpha=1)
        else:
            ax.scatter(X[i, 0], X[i, 1], c='C'+str(int(X[i, 2])), alpha=0.3)
    if type == 'learning' or type == 'final':
        for i in range(len(C)):
            ax.scatter(C[i, 0], C[i, 1], marker='X', c='C'+str(i+1), s=100)
    if algorithm == 'kohonen':
        ax.plot(C[:, 0], C[:, 1], color='blue', alpha=0.6)
    if type == 'final':
        for i in range(len(C)):
            ax.plot(center_data[i::len(C), 0], center_data[i::len(C), 1], c='C'+str(i+1), alpha=0.8)
    ax.set_xlim(-10, 10)
    ax.set_ylim(-10, 10)
    ax.set_ylabel('Y')
    ax.set_xlabel('X')
    ax.grid()
    fig.show()
    if type == 'final':
        return fig
    plt.close(fig)


def quantification(X, k, center_generation, algorithm, clas='plot', epochs=1, learn_rate=0.1, neighbour_rate=1, tired=0, policy='WTA'):
    # Center/Neuron position generation
    if center_generation == 'random':
        C = np.array([[random.uniform(-10, 10), random.uniform(-10, 10)] for _ in range(k)])
    elif center_generation == 'in':
        C = np.array([random.choice(X[:, :]) for _ in range(k)])
    elif center_generation == 'random_adapted':
        x_min = min(X[:, 0])
        x_max = max(X[:, 0])
        y_min = min(X[:, 1])
        y_max = max(X[:, 1])
        C = np.array([[random.uniform(x_min, x_max), random.uniform(y_min, y_max)] for _ in range(k)])
    elif center_generation == 'circle':
        x_avarage = np.mean(X[:, 0])
        y_avarage = np.mean(X[:, 1])
        r = (abs(x_avarage)+abs(max(X[:, 0])))/2
        pi = math.pi
        rand = np.random.uniform(0, 2)
        C = np.array([[math.cos(2*pi/k*x+pi*rand)*r + x_avarage, math.sin(2*pi/k*x+pi*rand)*r + y_avarage] for x in range(0, k)])

    tired_array = []
    cost_data = [cost(X, C)]                                    # for errors in iterations
    center_data = copy.deepcopy(C)                              # for center positions in iterations
    all_iterations = epochs * len(X)                            # for calculating value of learn_rate and eta in iterations
    if clas == 'plot':
        draw(assignment(X, C), C, 'learning', center_data, algorithm)  # draw the first plot with data assigned and centers/neurons
    if algorithm == 'kmeans':
        step_for_xaxes = 1
        while True:
            old_C = copy.deepcopy(C)
            updateCentersPositions(assignment(X, C), C)
            if clas != 'table':
                center_data = np.append(center_data, C, axis=0)  # adds centers/neurons postions to data for final plot traces
            if clas == 'plot':
                cost_data.append(cost(X, C))  # draw(assignment(X, C), C, 'learning', center_data, algorithm)
            if np.array_equal(old_C, C):
                break
    else:
        step_for_xaxes = int(all_iterations / 10)  # for drawing well spaced xaxes tics in error plots
        for i in range(epochs):                                     # goes through all epochs
            np.random.shuffle(X)                                    # shuffles data so the ordering for update is random
            for j in range(len(X)):                                 # goes through all data one by one
                curr_iter = j + i * len(X)
                winner = getWinnerFuntion(algorithm)(X[j], C, tired_array)
                if tired > 0:
                    if type(winner) is np.ndarray:
                        tired_array.append(int(winner[0]))
                    else:
                        tired_array.append(int(winner))
                updateNeuronsPositions(winner, curr_iter, X[j], C,  # updates neurons positions depending on algorithm and its policy
                                       learn_rate, neighbour_rate,
                                       all_iterations, algorithm, policy)
                if 0 < tired <= curr_iter+1:
                    tired_array.pop(0)
                if clas == 'plot':
                    cost_data.append(cost(X, C))  # adds error of current iteration to data
            if clas != 'table':
                center_data = np.append(center_data, C, axis=0)         # adds centers/neurons postions to data for final plot traces
            if clas == 'plot':
                draw(assignment(X, C), C, 'learning', center_data, algorithm)  # draw centers/neurons with assigned data at the end of each epoch
    if clas == 'plot':
        fig = draw(assignment(X, C), C, 'final', center_data, algorithm)
        return cost_data, step_for_xaxes
    elif clas == 'table':
        return cost(X, C), inactiveNeurons(assignment(X, C), C)
    elif clas == 'final':
        fig = draw(assignment(X, C), C, 'final', center_data, algorithm)  # draw the final plot with traces of centers/neurons
        return fig  # return final plot

figure_x = None
figure_y = None
C_empty = None
print("Witam w programie do kwantyzacji danych. \nProsze wybrac figury do wygenerowania danych:")
while True:
    print("[1] Kolo\n[2] Okrag\n[3] Prostokat\n[4] Kwadrat\n[5] Odcinek\n[6] Trojkat\n[7] Czworokat")
    figure_choice = int(input())
    if 1<= figure_choice <= 7:
        if not 5 <= figure_choice <=7:
            print("Podaj srodek figury:")
            print("X: ")
            figure_x = float(input())
            print("Y: ")
            figure_y = float(input())
        print("Liczba punktow:")
        figure_n = int(input())
        if figure_n >= 0:
            if 'X' in dir():
                X = np.append(X, getPointsInFigures(figure_choice)(figure_x, figure_y, figure_n), axis=0)
            else:
                X = getPointsInFigures(figure_choice)(figure_x, figure_y, figure_n)
            draw(X, C_empty, 'preview')
            print("Kolejna figura?\n[1] TAK\n[2] NIE")
            exit_data_making = int(input())
            if exit_data_making == 2:
                break
        else:
            print("Bledna liczba punktow.")
    else:
        print("Bledny wybor.")


#wariant na 3 punkt 1
quantification_data_3_1 = [['gas'],
                           ['kohonen', 'WTA'],
                           ['kohonen', 'WTM']]
for sample in quantification_data_3_1:
    try:
        policy = sample[1]
    except IndexError:
        policy = ''
    fig, ax = plt.subplots(figsize=(8, 8))
    for i in range(2, 21, 2):
        print(i)
        cost_data, step_for_xaxes = quantification(X, i, 'random', sample[0], 'plot', 8, 0.1, 0.8, 1, policy)
        ax.plot(np.arange(0, len(cost_data)), cost_data, label=str(i)+' neurons')
    plt.xticks(np.arange(0, len(cost_data)+1, step_for_xaxes))
    ax.set_title('Error at iterations with different amount of centers for '+sample[0]+''+policy)
    ax.set_xlabel('Iteration')
    ax.set_ylabel('Error')
    ax.legend()
    ax.set_ylim(top=3)
    fig.show()
    fig.savefig('outSprawko3_1'+sample[0]+policy+'.png')
fig.close()

# wariant na 3 punkt 2
outFile = open('lllllllllllllllllllllllll1.txt', 'a+')
cost_data_3_2 = []
inactive_neurons = []
# center_generation, algorytm, learn_rate, neigobur_rate, tunrs_tired, policy
quantification_data = [['random', 'kohonen', 0.1, 1, 0, 'WTA'],
                       ['random', 'kohonen', 0.5, 1, 0, 'WTA'],
                       ['random', 'kohonen', 1, 1, 0, 'WTA'],
                       ['random', 'kohonen', 1, 1, 5, 'WTA'],
                       ['random', 'kohonen', 1, 1, 10, 'WTA'],
                       ['random', 'kohonen', 1, 1, 15, 'WTA'],
                       ['in', 'kohonen', 1, 1, 0, 'WTA'],
                       ['in', 'kohonen', 1, 1, 2, 'WTA'],
                       ['random', 'kohonen', 0.1, 1, 0, 'WTM'],
                       ['random', 'kohonen', 0.5, 1, 0, 'WTM'],
                       ['random', 'kohonen', 1, 1, 0, 'WTM'],
                       ['random', 'kohonen', 1, 0.5, 0, 'WTM'],
                       ['random', 'kohonen', 1, 1, 0, 'WTM'],
                       ['random', 'kohonen', 1, 1.5, 0, 'WTM'],
                       ['random', 'kohonen', 1, 0.5, 1, 'WTM'],
                       ['random', 'kohonen', 1, 0.5, 3, 'WTM'],
                       ['in', 'kohonen', 1, 0.5, 0, 'WTM'],
                       ['in', 'kohonen', 1, 0.5, 2, 'WTM'],
                       ['random', 'gas', 0.1, 1, 0],
                       ['random', 'gas', 0.5, 1, 0],
                       ['random', 'gas', 1, 1, 0],
                       ['random', 'gas', 1, 0.5, 0],
                       ['random', 'gas', 1, 1, 0],
                       ['random', 'gas', 1, 1.5, 0],
                       ['random', 'gas', 1, 1, 1],
                       ['random', 'gas', 1, 1, 3],
                       ['in', 'gas', 1, 1, 0],
                       ['in', 'gas', 1, 1, 2]]

for i in range(len(quantification_data)):
    print('opcja '+str(i))
    cost_data_3_2 = []
    inactive_neurons = []
    curr_quant = quantification_data.pop(0)
    try:
        policy = curr_quant[5]
    except IndexError:
        policy = ''
    for j in range(100):
        print('opcja '+str(i)+'tura '+str(j))
        last_cost, inactive_neuron = quantification(X, 20, curr_quant[0], curr_quant[1], 'table',
                                                    8, curr_quant[2], curr_quant[3], curr_quant[4], policy)
        cost_data_3_2.append(last_cost)
        inactive_neurons.append(inactive_neuron)
    outFile.write(curr_quant[1]+' '+policy+' center='+curr_quant[0]+' k=20 epo=8 learn='+str(curr_quant[2])+' neighb='+str(curr_quant[3])+' tired='+str(curr_quant[4])
                  + ' avg_cost='+str(np.mean(cost_data_3_2))+' div_cost='+str(np.std(np.array(cost_data_3_2)))
                  + ' min_cost='+str(cost_data_3_2[np.argmin(cost_data_3_2)])+' avg_inac='+str(np.mean(inactive_neurons))
                  + ' div_inac='+str(np.std(np.array(inactive_neurons)))+'\n')
outFile.close()

# wariant na 3 punkt 3
quantification_data_3_1 = [['gas'],
                           ['kohonen', 'WTA'],
                           ['kohonen', 'WTM']]
for sample in quantification_data_3_1:
    try:
        policy = sample[1]
    except IndexError:
        policy = ''
    fig, ax = plt.subplots(figsize=(8, 8))
    for i in [2, 10]:
        fig = quantification(X, i, 'random', sample[0], 'final', 8, 0.1, 1, 0, policy)
        fig.show()
        fig.savefig('outSprawko3_3_2' + sample[0] + policy + str(i) + '.png')
    fig.close()

# wariant na 4 opcja 1
lenghts =[]
fig, ax = plt.subplots(figsize=(8, 8))
for i in range(2, 21, 2):
    print(i)
    cost_data, step_for_xaxes = quantification(X, i, 'in', 'kmeans', 'plot')
    lenghts.append(len(cost_data))
    ax.plot(np.arange(0, len(cost_data)), cost_data, label=str(i)+' centers')
plt.xticks(np.arange(0, max(lenghts), step_for_xaxes))
ax.set_title('Error at iterations with different amount of centers for kmeans')
ax.set_xlabel('Iteration')
ax.set_ylabel('Error')
ax.legend()
fig.show()
fig.savefig('outSprawko3_1kmeans2fig.png')
fig.close()

# wariant na 4 opcja 2
outFile = open('oooooooooooooo2.txt', 'a+')
center_generation_data = ['random', 'random_adapted', 'circle', 'in']
for i in range(len(center_generation_data)):
    cost_data_4_2 = []
    inactive_neurons = []
    center_gen = center_generation_data.pop(0)
    for j in range(100):
        print('opcja '+str(i)+'tura '+str(j))
        last_cost, inactive_neuron = quantification(X, 20, center_gen, 'kmeans', 'table')
        cost_data_4_2.append(last_cost)
        inactive_neurons.append(inactive_neuron)
    outFile.write('kmeans'+' center='+center_gen+' k=20 epo=8'
                  + ' avg_cost='+str(np.mean(cost_data_4_2))+' div_cost='+str(np.std(np.array(cost_data_4_2)))
                  + ' min_cost='+str(cost_data_4_2[np.argmin(cost_data_4_2)])+' avg_inac='+str(np.mean(inactive_neurons))
                  + ' div_inac='+str(np.std(np.array(inactive_neurons)))+'\n')
outFile.close()

# wariant na 4 opcja 3
fig, ax = plt.subplots(figsize=(8, 8))
for i in [2, 10]:
    fig = quantification(X, i, 'in', 'kmeans', 'final')
    fig.show()
    fig.savefig('outSprawko4_3_2 kmeans' + str(i) + '.png')
fig.close()
